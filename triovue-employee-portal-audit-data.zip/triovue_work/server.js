// Dependency-free Node.js server. Node 18+ required.
const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = Number(process.env.PORT || 3000);
const crypto = require('crypto');
const sessions = new Map();
const DEMO_USERS = [
 {username:'employee',password:'employee123',name:'Antos Pravin',role:'employee',employee:'Antos Pravin'},
 {username:'admin',password:'admin123',name:'Portal Admin',role:'admin'},
 {username:'superadmin',password:'super123',name:'Super Admin',role:'superadmin'}
];
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){const hash=crypto.scryptSync(password,salt,64).toString('hex');return {salt,hash};}
function verifyPassword(password,record){if(!record||!record.salt||!record.hash)return false;const test=crypto.scryptSync(password,record.salt,64);return crypto.timingSafeEqual(test,Buffer.from(record.hash,'hex'));}
function makeUsername(name){const base=String(name||'employee').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g,'.').replace(/^\.|\.$/g,'')||'employee';let candidate=base,n=1;while((db.users||[]).some(u=>u.username===candidate)||DEMO_USERS.some(u=>u.username===candidate)){candidate=base+'.'+(++n);}return candidate;}
function currentUser(req){const c=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('triovue_session='));return c?sessions.get(c.split('=')[1]):null;}
function roleCanRead(role,collection){if(role==='superadmin'||role==='admin')return true;return ['employees','attendance','tasks','projects','leaves','holidays','timesheets','announcements'].includes(collection);}

const ROOT = __dirname;
const DB_FILE = path.join(ROOT, 'data.json');
const initial = {
 employees:[{id:'EMP001',name:'Antos Pravin',department:'Product Development',designation:'Product Development',email:'pravin@triovue.example',phone:'',manager:'',joined:'2025-01-06',status:'Active'},{id:'EMP002',name:'Muthukumar',department:'Hardware',designation:'Hardware Engineer',email:'',phone:'',manager:'Antos Pravin',joined:'2025-03-10',status:'Active'},{id:'EMP003',name:'Karthik',department:'Firmware',designation:'Embedded Engineer',email:'',phone:'',manager:'Antos Pravin',joined:'2025-04-14',status:'Active'}],
 attendance:[],tasks:[{id:'TSK001',project:'Telephone Product',title:'Review product requirements',employee:'Muthukumar',department:'Hardware',priority:'High',start:new Date().toISOString().slice(0,10),due:new Date().toISOString().slice(0,10),progress:35,status:'In Progress',reviewer:'Antos Pravin',remarks:''}],
 holidays:[{id:'HOL001',date:'2026-12-25',name:'Christmas',type:'Company Holiday'}],leaves:[],projects:[{id:'PRJ001',name:'Telephone Product',client:'Internal',manager:'Antos Pravin',department:'Product Development',start:new Date().toISOString().slice(0,10),target:'2027-02-28',stage:'Development',progress:20,status:'Active',remarks:''}],timesheets:[],announcements:[{id:'ANN001',title:'Welcome to the Employee Portal',description:'Use this portal to manage attendance, tasks and project updates.',department:'All',published:new Date().toISOString().slice(0,10),expiry:'',by:'Super Admin',status:'Active'}],audit:[]
};
function load(){if(!fs.existsSync(DB_FILE))fs.writeFileSync(DB_FILE,JSON.stringify(initial,null,2));try{return JSON.parse(fs.readFileSync(DB_FILE,'utf8'));}catch{return JSON.parse(JSON.stringify(initial));}}
let db=load();if(!Array.isArray(db.users))db.users=[];function save(){fs.writeFileSync(DB_FILE,JSON.stringify(db,null,2));}function log(action,entity,id){db.audit.unshift({id:'LOG'+Date.now(),action,entity,recordId:id,at:new Date().toISOString(),by:'Local Admin'});db.audit=db.audit.slice(0,500);save();}
const collections=['employees','attendance','tasks','holidays','leaves','projects','timesheets','announcements'];
function send(res,status,data,type='application/json; charset=utf-8'){res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store'});res.end(type.startsWith('application/json')?JSON.stringify(data):data);}
function body(req){return new Promise((resolve,reject)=>{let raw='';req.on('data',c=>{raw+=c;if(raw.length>1e6)reject(new Error('Request too large'));});req.on('end',()=>{try{resolve(raw?JSON.parse(raw):{});}catch{reject(new Error('Invalid JSON'));}});});}
const server=http.createServer(async(req,res)=>{try{const u=new URL(req.url,'http://localhost');const parts=u.pathname.split('/').filter(Boolean).map(decodeURIComponent);if(req.method==='GET'&&u.pathname==='/api/health')return send(res,200,{ok:true,app:'Triovue Employee Portal',version:'1.0.0'});if(parts[0]==='api'){
 if(req.method==='POST'&&parts[1]==='login'){const b=await body(req);let user=DEMO_USERS.find(x=>x.username===b.username&&x.password===b.password);if(!user){const account=db.users.find(x=>x.username===b.username&&x.status!=='Disabled');if(account&&verifyPassword(b.password,account.passwordHash)){user={username:account.username,name:account.name,role:'employee',employee:account.name,employeeId:account.employeeId};}}if(!user)return send(res,401,{error:'Invalid username or password'});const token=crypto.randomBytes(32).toString('hex');const {password,...safe}=user;sessions.set(token,safe);res.writeHead(200,{'Set-Cookie':`triovue_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800`,'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});return res.end(JSON.stringify({user:safe}));}
 if(req.method==='POST'&&parts[1]==='logout'){const user=currentUser(req),c=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('triovue_session='));if(c)sessions.delete(c.split('=')[1]);res.writeHead(200,{'Set-Cookie':'triovue_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0','Content-Type':'application/json; charset=utf-8'});return res.end(JSON.stringify({ok:true}));}
 if(req.method==='GET'&&parts[1]==='me'){const user=currentUser(req);return user?send(res,200,{user}):send(res,401,{error:'Please sign in'});}
 const auth=currentUser(req);if(!auth)return send(res,401,{error:'Please sign in to continue'});
 if(parts[1]==='users'&&auth.role!=='superadmin')return send(res,403,{error:'Super Admin access required'});
 if(['POST','PUT','DELETE'].includes(req.method)&&auth.role==='employee'&&!(req.method==='POST'&&parts[1]==='attendance'&&parts[2]==='punch'))return send(res,403,{error:'Your role does not have permission to change this information'});
 if(auth.role==='admin'&&parts[1]==='users')return send(res,403,{error:'Super Admin access required'});
 if(req.method==='GET'&&parts[1]==='data'){if(auth.role==='employee'){const own=db.employees.filter(x=>auth.employeeId?x.id===auth.employeeId:x.name===auth.employee);const name=auth.employee;return send(res,200,{employees:own,attendance:db.attendance.filter(x=>x.employee===name),tasks:db.tasks.filter(x=>x.employee===name),projects:db.projects,leaves:db.leaves.filter(x=>x.employee===name),holidays:db.holidays,timesheets:db.timesheets.filter(x=>x.employee===name),announcements:db.announcements,audit:[]});}const {users,...safeDb}=db;return send(res,200,safeDb);}
 if(req.method==='GET'&&parts[1]==='export'&&collections.includes(parts[2])){if(auth.role==='employee'&&!['attendance','tasks','leaves','timesheets'].includes(parts[2]))return send(res,403,{error:'Access denied'});const rows=auth.role==='employee'?db[parts[2]].filter(x=>x.employee===auth.employee):db[parts[2]],cols=[...new Set(rows.flatMap(x=>Object.keys(x)))];const csv=[cols.join(','),...rows.map(r=>cols.map(k=>'"'+String(r[k]??'').replaceAll('"','""')+'"').join(','))].join('\n');res.writeHead(200,{'Content-Type':'text/csv','Content-Disposition':`attachment; filename="${parts[2]}.csv"`});return res.end(csv);}
 if(!collections.includes(parts[1]))return send(res,404,{error:'Unknown collection'});const c=parts[1];if(!roleCanRead(auth.role,c))return send(res,403,{error:'Access denied'});
 if(req.method==='GET'&&parts.length===2)return send(res,200,auth.role==='employee'?db[c].filter(x=>x.employee===auth.employee):db[c]);
 if(req.method==='POST'&&c==='attendance'&&parts[2]==='punch'){const b=await body(req);if(auth.role==='employee'&&b.employee!==auth.employee)return send(res,403,{error:'You can only record your own attendance'});if(!b.employee||!['Check in','Lunch out','Lunch in','Check out'].includes(b.event))return send(res,400,{error:'Employee and valid event are required'});const date=new Date().toISOString().slice(0,10);let row=db.attendance.find(x=>x.employee===b.employee&&x.date===date);if(!row){row={id:'ATT'+Date.now(),employee:b.employee,date,checkIn:'',lunchOut:'',lunchIn:'',checkOut:'',status:'Present'};db.attendance.unshift(row);}const key={'Check in':'checkIn','Lunch out':'lunchOut','Lunch in':'lunchIn','Check out':'checkOut'}[b.event];if(row[key])return send(res,409,{error:`${b.event} already recorded`});row[key]=new Date().toISOString();log(b.event.toUpperCase(),'attendance',row.id);return send(res,200,row);}
 if(req.method==='POST'&&parts.length===2){if(auth.role==='employee')return send(res,403,{error:'Access denied'});const b=await body(req);if(c==='employees'&&!String(b.name||'').trim())return send(res,400,{error:'Employee name is required'});const item={...b,name:c==='employees'?String(b.name).trim():b.name,id:b.id||c.slice(0,3).toUpperCase()+Date.now()};db[c].unshift(item);log('CREATE',c,item.id);
 if(c==='employees'){
   const username=makeUsername(item.name),password=crypto.randomBytes(12).toString('base64url');
   const passwordHash=hashPassword(password);
   db.users.push({id:'USR'+Date.now(),username,name:item.name,employeeId:item.id,passwordHash,status:'Active',createdAt:new Date().toISOString(),mustChangePassword:true});
   save();return send(res,201,{...item,loginCredentials:{username,password,temporary:true}});
 }
 return send(res,201,item);}
 if(req.method==='PUT'&&parts.length===3){if(auth.role==='employee')return send(res,403,{error:'Access denied'});const b=await body(req),i=db[c].findIndex(x=>x.id===parts[2]);if(i<0)return send(res,404,{error:'Record not found'});db[c][i]={...db[c][i],...b,id:parts[2]};if(c==='employees'){const account=db.users.find(x=>x.employeeId===parts[2]);if(account&&b.name){account.name=String(b.name).trim();}}log('UPDATE',c,parts[2]);return send(res,200,db[c][i]);}
 if(req.method==='DELETE'&&parts.length===3){if(auth.role==='employee')return send(res,403,{error:'Access denied'});const n=db[c].length;db[c]=db[c].filter(x=>x.id!==parts[2]);if(n===db[c].length)return send(res,404,{error:'Record not found'});if(c==='employees'){const account=db.users.find(x=>x.employeeId===parts[2]);if(account)account.status='Disabled';}log('DELETE',c,parts[2]);return send(res,200,{ok:true});}
 return send(res,404,{error:'API route not found'});
 }
 let file=parts.length?path.join(ROOT,'public',...parts):path.join(ROOT,'public','index.html');if(!file.startsWith(path.join(ROOT,'public')))return send(res,403,{error:'Forbidden'});if(!fs.existsSync(file)||fs.statSync(file).isDirectory())file=path.join(ROOT,'public','index.html');const ext=path.extname(file);const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml'};res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream'});fs.createReadStream(file).pipe(res);
 }catch(e){send(res,500,{error:e.message||'Internal server error'});}});
server.listen(PORT,'0.0.0.0',()=>console.log(`Triovue Employee Portal running at http://localhost:${PORT}`));

// Usage:  node generate-docs.js
// Writes a PDF into the output/ folder for every invoice and proforma saved in your deals data.
// If none exist yet, it writes a demo invoice and proforma so you can see the layout.
const fs = require("fs");
const path = require("path");
const cfg = require("./config");
const { buildPdf } = require("./pdf");

const company = JSON.parse(fs.readFileSync(cfg.file("company.json"), "utf8"));
const deals = fs.existsSync(cfg.file("deals.json")) ? JSON.parse(fs.readFileSync(cfg.file("deals.json"), "utf8")) : [];
const outDir = path.join(__dirname, "output");
fs.mkdirSync(outDir, { recursive: true });

const jobs = [];
deals.forEach((deal) => (deal.documents || []).forEach((doc) => jobs.push({ deal, doc })));

if (jobs.length === 0) {
  const deal = deals[0] || { company: "Sample Client Pvt Ltd", paymentStatus: "Pending", productStatus: "Not started" };
  const base = { date: new Date().toISOString(), amount: 100000, description: "Product - Phase 1 payment", payMode: deal.payMode || "Bank transfer (NEFT/RTGS)" };
  jobs.push({ deal, doc: { ...base, type: "proforma", number: "PF-DEMO-0001" } });
  jobs.push({ deal, doc: { ...base, type: "invoice", number: "INV-DEMO-0001" } });
  console.log("No saved documents found - generating demo files.");
}

jobs.forEach(({ deal, doc }) => {
  const file = path.join(outDir, `${doc.number}.pdf`);
  const pdf = buildPdf({ company, deal, doc });
  pdf.pipe(fs.createWriteStream(file));
  pdf.end();
  console.log("Created", path.relative(__dirname, file));
});

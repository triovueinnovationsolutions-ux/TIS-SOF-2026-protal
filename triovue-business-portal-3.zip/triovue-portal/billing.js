// Shared helpers for invoices and proformas (used by server.js, pdf.js and generate-docs.js)

const inr = (n) => "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function amountInWords(num) {
  const a = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
  const b = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
  const two = (n) => (n < 20 ? a[n] : b[Math.floor(n / 10)] + (n % 10 ? " " + a[n % 10] : ""));
  const three = (n) => (n >= 100 ? a[Math.floor(n / 100)] + " Hundred" + (n % 100 ? " " + two(n % 100) : "") : two(n));
  const toWords = (n) => {
    if (n === 0) return "Zero";
    const parts = [];
    const crore = Math.floor(n / 10000000); n %= 10000000;
    const lakh = Math.floor(n / 100000); n %= 100000;
    const thou = Math.floor(n / 1000); n %= 1000;
    if (crore) parts.push(three(crore) + " Crore");
    if (lakh) parts.push(two(lakh) + " Lakh");
    if (thou) parts.push(two(thou) + " Thousand");
    if (n) parts.push(three(n));
    return parts.join(" ");
  };
  const rupees = Math.floor(num);
  const paise = Math.round((num - rupees) * 100);
  return "Indian Rupees " + toWords(rupees) + (paise ? " and " + two(paise) + " Paise" : "") + " Only";
}

// Returns the tax lines and total. Same state code in both GSTINs -> CGST + SGST, different -> IGST.
function taxBreakdown(amount, rate, sellerGstin = "", buyerGstin = "") {
  const tax = Math.round(amount * rate) / 100;
  const s = sellerGstin.slice(0, 2), b = buyerGstin.slice(0, 2);
  let lines;
  if (/^\d{2}$/.test(s) && /^\d{2}$/.test(b)) {
    lines = s === b
      ? [[`CGST @ ${rate / 2}%`, tax / 2], [`SGST @ ${rate / 2}%`, tax / 2]]
      : [[`IGST @ ${rate}%`, tax]];
  } else {
    lines = [[`GST @ ${rate}%`, tax]];
  }
  return { tax, total: amount + tax, lines };
}

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

module.exports = { inr, amountInWords, taxBreakdown, esc };

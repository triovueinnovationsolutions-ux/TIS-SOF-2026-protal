// Builds an invoice / proforma PDF with PDFKit (Triovue logo theme). Returns the PDFDocument stream; caller pipes it and calls .end()
const path = require("path");
const PDFDocument = require("pdfkit");
const { inr, amountInWords, taxBreakdown } = require("./billing");

const FONT = path.join(__dirname, "fonts", "DejaVuSans.ttf");
const FONT_BOLD = path.join(__dirname, "fonts", "DejaVuSans-Bold.ttf");
const LOGO = path.join(__dirname, "assets", "logo.png");
const SEAL = path.join(__dirname, "assets", "seal.png");
const LEFT = 50, RIGHT = 545, WIDTH = RIGHT - LEFT;
const INK = "#173a56", ACCENT = "#3a7ab0", CYAN = "#62c4dc", MUTED = "#55697a", LINE = "#c8d6e2", SHADE = "#eef4fa";

function buildPdf({ company: co, deal, doc }) {
  const isInvoice = doc.type === "invoice";
  const title = isInvoice ? "TAX INVOICE" : "PROFORMA INVOICE";
  const { total, lines } = taxBreakdown(doc.amount, Number(co.gstRate) || 0, co.gstin || "", deal.gstin || "");
  const date = new Date(doc.date).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });

  const pdf = new PDFDocument({ size: "A4", margin: 50, info: { Title: `${title} ${doc.number}`, Author: co.name } });
  pdf.registerFont("R", FONT);
  pdf.registerFont("B", FONT_BOLD);
  const gradient = (x, y, w, h) => { const g = pdf.linearGradient(x, 0, x + w, 0); g.stop(0, "#437396").stop(1, "#66c8dc"); pdf.rect(x, y, w, h).fill(g); };

  // ----- Header: logo + document title -----
  pdf.image(LOGO, LEFT, 24, { width: 165 });
  pdf.font("B").fontSize(15).fillColor(INK).text(title, 340, 30, { width: 205, align: "right" });
  pdf.font("R").fontSize(9).fillColor(MUTED).text(`${doc.number}\nDate: ${date}`, 340, pdf.y + 4, { width: 205, align: "right" });
  gradient(0, 88, 595, 5);

  // ----- From / Bill to -----
  let y = 112;
  const label = (t, x, yy) => {
    pdf.font("B").fontSize(7.5).fillColor(MUTED).text(t, x, yy);
    pdf.moveTo(x, yy + 11).lineTo(x + pdf.widthOfString(t) + 2, yy + 11).lineWidth(1.5).strokeColor(ACCENT).stroke();
  };
  label("FROM", LEFT, y); label("BILL TO", 310, y);
  pdf.fillColor("#000").font("B").fontSize(9.5).text(co.name, LEFT, y + 18, { width: 240 });
  pdf.font("R").fontSize(9).text(
    [co.address, co.gstin && `GSTIN: ${co.gstin}`, co.email, co.website, co.phone].filter(Boolean).join("\n"), LEFT, pdf.y + 1, { width: 240 });
  const fromEnd = pdf.y;
  pdf.font("B").fontSize(9.5).text(deal.company, 310, y + 18, { width: 235 });
  pdf.font("R").fontSize(9).text(
    [deal.contact && `Attn: ${deal.contact}`, deal.billingAddress, deal.gstin && `GSTIN: ${deal.gstin}`, deal.email && `Email: ${deal.email}`, deal.phone && `Phone: ${deal.phone}`]
      .filter(Boolean).join("\n"), 310, pdf.y + 1, { width: 235 });
  y = Math.max(fromEnd, pdf.y) + 14;

  // ----- Payment strip -----
  pdf.rect(LEFT, y, WIDTH, 36).fill(SHADE);
  pdf.rect(LEFT, y, 4, 36).fill(ACCENT);
  [["PAYMENT MODE", doc.payMode], ["PAYMENT STATUS", deal.paymentStatus || "Pending"], ["PRODUCT STATUS", deal.productStatus || "Not started"]].forEach(([k, v], i) => {
    const x = LEFT + 14 + i * 160;
    pdf.font("R").fontSize(7).fillColor(MUTED).text(k, x, y + 7).fillColor("#000").fontSize(9).text(v, x, y + 18, { width: 150 });
  });
  y += 36 + 18;

  // ----- Items table -----
  const cDesc = LEFT + 34, cAmt = 420;
  pdf.rect(LEFT, y, WIDTH, 22).fill(INK);
  pdf.fillColor("#fff").font("B").fontSize(8)
    .text("#", LEFT + 10, y + 7).text("DESCRIPTION", cDesc + 8, y + 7)
    .text("AMOUNT", cAmt, y + 7, { width: RIGHT - cAmt - 8, align: "right" });
  pdf.font("R").fontSize(9);
  const descW = cAmt - cDesc - 16;
  const rowH = Math.max(28, pdf.heightOfString(doc.description, { width: descW }) + 16);
  const ry = y + 22;
  pdf.fillColor("#000").text("1", LEFT + 10, ry + 9).text(doc.description, cDesc + 8, ry + 9, { width: descW })
    .text(inr(doc.amount), cAmt, ry + 9, { width: RIGHT - cAmt - 8, align: "right" });
  pdf.lineWidth(0.5).strokeColor(LINE).rect(LEFT, ry, WIDTH, rowH).stroke();
  pdf.moveTo(cDesc, ry).lineTo(cDesc, ry + rowH).stroke();
  pdf.moveTo(cAmt, ry).lineTo(cAmt, ry + rowH).stroke();

  // ----- Totals -----
  let ty = ry + rowH + 8;
  const rows = [["Taxable value", doc.amount], ...lines, ["Total", total]];
  const tx = 340, tw = RIGHT - tx;
  rows.forEach(([lab, val], i) => {
    const last = i === rows.length - 1;
    if (last) pdf.rect(tx, ty, tw, 24).fill(ACCENT);
    pdf.fillColor(last ? "#fff" : "#000").font(last ? "B" : "R").fontSize(9)
      .text(lab, tx + 8, ty + 8).text(inr(val), tx, ty + 8, { width: tw - 8, align: "right" });
    if (!last) pdf.lineWidth(0.5).strokeColor(LINE).rect(tx, ty, tw, 24).stroke();
    ty += 24;
  });

  pdf.font("B").fontSize(9).fillColor("#000").text("Amount in words: ", LEFT, ty + 14, { continued: true })
    .font("R").text(amountInWords(total), { width: WIDTH });

  // ----- Bank details / terms -----
  const by = pdf.y + 22;
  const b = co.bank || {};
  const bank = [b.accountName, b.bankName, b.accountNumber && `A/c No: ${b.accountNumber}`, b.ifsc && `IFSC: ${b.ifsc}`, b.upi && `UPI: ${b.upi}`].filter(Boolean).join("\n") || "Bank details not added yet";
  label("BANK DETAILS", LEFT, by); label("TERMS", 310, by);
  pdf.fillColor("#000").font("R").fontSize(9).text(bank, LEFT, by + 20, { width: 240 });
  const bankEnd = pdf.y;
  const terms = (co.terms || "") + (isInvoice ? "" : "\n\nThis is a proforma invoice for payment processing. It is not a tax invoice and cannot be used to claim input tax credit.");
  pdf.text(terms, 310, by + 20, { width: 235 });

  // ----- Seal, signature -----
  const sy = Math.max(bankEnd, pdf.y) + 26;
  pdf.font("B").fontSize(9).fillColor("#000").text(`For ${co.name}`, 300, sy, { width: 245, align: "right" });
  let ay = sy + 14;
  if (co.showSeal !== false) { pdf.image(SEAL, RIGHT - 100, ay, { width: 100 }); ay += 100 * 334 / 420 + 6; } else ay += 36;
  pdf.font("R").fontSize(9).text("Authorised signatory", 300, ay, { width: 245, align: "right" });

  // ----- Footer band -----
  pdf.page.margins.bottom = 0;
  gradient(0, 808, 595, 4);
  pdf.rect(0, 812, 595, 30).fill(INK);
  pdf.font("R").fontSize(8.5).fillColor("#dbe8f2")
    .text([co.website, co.email].filter(Boolean).join("   |   "), 0, 823, { width: 595, align: "center", lineBreak: false });

  return pdf;
}

module.exports = { buildPdf };

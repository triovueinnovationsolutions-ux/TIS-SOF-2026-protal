# Triovue Innovation Solutions - Business development portal

## Run on your computer
1. Install Node.js (nodejs.org) and open this folder in VS Code.
2. Terminal (Ctrl + `):  npm install
3. Start:               npm start
4. Open:                http://localhost:3000
Stop the server with Ctrl + C.

## Logins (created on first start)
- Admin:     admin / admin123        -> can edit everything
- Employee:  employee / employee123  -> view only
CHANGE BOTH PASSWORDS on first login. Forgot the admin password? Stop the server, delete data/users.json, start again.

## What is in the portal
Tabs: Deals | Follow-ups | Payments | Admin & security (admin only).
Top of every screen: Active / Inactive deal counts (click to filter) and alerts for follow-ups due,
overdue payments and clients who have not replied.

1. CRM and lead management (open a deal with "Details")
   lead source (LinkedIn, website, referral, direct enquiry), client contact details, contact person and
   designation, enquiry date, next follow-up date, lead owner, lead conversion status.
2. Payment and finance
   advance payment, milestone-based payments, GST calculation, payment due dates, partial payments,
   overdue payment alerts, customer payment history. Money received is applied to the payment schedule in
   due-date order, so partial and overdue amounts are worked out automatically.
3. Follow-up and communication
   follow-up reminders (overdue / today / upcoming), client meeting records, email history, discussion notes,
   next action, pending client responses.
4. Security and administration
   role-based access control (enforced on the server), password reset, login history, audit log, user activity
   history (Activity button next to each user), data backup and recovery.

## First thing to do: Company settings (Admin tab)
Enter your GST number, registered address, phone and bank details. They appear on every invoice, proforma and statement.

## Invoices and proformas
In a deal: Proforma / Invoice button, then "Download PDF". They carry the Triovue logo and the company seal and
signature (switch the seal off in Company settings if you do not want it). Terminal: node generate-docs.js
Logo and seal files are in assets/ (replace logo.png / seal.png to change them).

## Backup and recovery
Automatic backups at start-up and every 24 hours (newest 30 kept in data/backups). Admin tab -> "Data backup and
recovery": create, download, restore from a stored backup or from a file. A safety copy is made before every restore.

## Put it on the internet (hosting)
1. Build command: npm install      Start command: npm start      Node 18 or newer.
2. Data is saved in files, so attach a PERSISTENT DISK and set the environment variable DATA_DIR to its path
   (for example DATA_DIR=/var/data). Backups are kept there too. Without a disk, data is lost on each redeploy.
3. Run a single instance only. Use HTTPS (the login cookie becomes Secure automatically).
4. Use a subdomain such as portal.triovue.com; health check URL: /healthz
5. Change the default passwords BEFORE going live and copy the backups folder somewhere safe regularly.

## Files
server.js (server, login, roles, API) | views/ (login.html, app.html) | templates.js, pdf.js, billing.js, generate-docs.js
(invoices) | config.js (DATA_DIR) | assets/ (logo, seal) | fonts/ | data/ (deals.json, company.json; users, audit,
logins and backups are created on first run)
Sign-in sessions are kept in memory, so everyone is signed out when the server restarts.

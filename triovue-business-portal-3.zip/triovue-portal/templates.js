// HTML for the printable invoice / proforma page and the statement of account (industrial theme)
const { inr, amountInWords, taxBreakdown, esc } = require("./billing");

const br = (t) => esc(t).replace(/\n/g, "<br>");
const fd = (v) => new Date(v).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });

const CSS = `
:root{--ink:#173a56;--accent:#3a7ab0;--cyan:#62c4dc;--muted:#55697a;--line:#c8d6e2;--shade:#eef4fa}
*{box-sizing:border-box}
body{margin:0;background:#dde6ee;color:#14212b;font-family:"Segoe UI",Arial,Helvetica,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.bar{text-align:center;padding:12px}
.bar button{padding:9px 20px;font-size:14px;cursor:pointer;background:var(--ink);color:#fff;border:0;border-bottom:3px solid var(--cyan);margin:0 4px}
.page{max-width:840px;margin:0 auto 24px;background:#fff;box-shadow:0 2px 10px #0003}
.band{background:#fff;padding:20px 30px;display:flex;justify-content:space-between;align-items:center;gap:20px;border-bottom:5px solid;border-image:linear-gradient(90deg,#437396,#66c8dc) 1}
.brand img{height:54px;display:block}
.doc{text-align:right}.doc h1{margin:0;font-size:22px;letter-spacing:2px;color:var(--ink)}.doc div{font-size:12px;color:var(--muted);margin-top:4px}
.body{padding:24px 30px 10px}
.cols{display:flex;gap:30px;margin-bottom:16px}.cols>div{flex:1;font-size:13px;line-height:1.55}
h3{font-size:11px;letter-spacing:1.5px;color:var(--muted);margin:0 0 6px;padding-bottom:4px;border-bottom:2px solid var(--accent);display:inline-block}
.strip{display:flex;background:var(--shade);border-left:4px solid var(--accent);margin-bottom:18px}
.strip div{flex:1;padding:10px 14px;font-size:13px}.strip small{display:block;font-size:10px;letter-spacing:1px;color:var(--muted);text-transform:uppercase}
table{width:100%;border-collapse:collapse;font-size:13px}
th{background:var(--ink);color:#fff;text-align:left;padding:9px;font-size:11px;letter-spacing:1px;text-transform:uppercase}
td{border:1px solid var(--line);padding:9px}
.num{text-align:right;font-variant-numeric:tabular-nums}
.totals{width:52%;margin-left:auto;margin-top:-1px}
.totals td{border:1px solid var(--line)}.grand td{background:var(--accent);color:#fff;font-weight:700;border-color:var(--accent)}
.words{font-size:13px;margin:14px 0 18px}.small{font-size:12px;color:#444;line-height:1.55}
.sign{text-align:right;font-size:13px;margin:28px 0 20px}
.seal{width:130px;height:auto;display:block;margin:6px 0 4px auto}
.foot{background:var(--ink);color:#dbe8f2;text-align:center;font-size:12px;padding:12px;letter-spacing:.5px;border-top:4px solid;border-image:linear-gradient(90deg,#437396,#66c8dc) 1}
.foot b{color:var(--cyan)}
tfoot td{font-weight:700;background:var(--shade)}
@media (max-width:640px){.band,.cols{flex-direction:column;align-items:flex-start}.doc{text-align:left}.strip{flex-direction:column}.totals{width:100%}.wrap{overflow-x:auto}}
@media print{body{background:#fff}.bar{display:none}.page{box-shadow:none;margin:0;max-width:none}}
@page{size:A4;margin:10mm}`;

const companyBlock = (co) =>
  `<b>${esc(co.name)}</b>` +
  (co.address ? `<br>${br(co.address)}` : "") +
  (co.gstin ? `<br>GSTIN: ${esc(co.gstin)}` : "") +
  (co.email ? `<br>${esc(co.email)}` : "") +
  (co.website ? `<br>${esc(co.website)}` : "") +
  (co.phone ? `<br>${esc(co.phone)}` : "");

const clientBlock = (deal) =>
  `<b>${esc(deal.company)}</b>` +
  (deal.contact ? `<br>Attn: ${esc(deal.contact)}` : "") +
  (deal.billingAddress ? `<br>${br(deal.billingAddress)}` : "") +
  (deal.gstin ? `<br>GSTIN: ${esc(deal.gstin)}` : "") +
  (deal.email ? `<br>Email: ${esc(deal.email)}` : "") +
  (deal.phone ? `<br>Phone: ${esc(deal.phone)}` : "");

const bankBlock = (co) => {
  const b = co.bank || {};
  return [b.accountName, b.bankName, b.accountNumber && `A/c No: ${b.accountNumber}`, b.ifsc && `IFSC: ${b.ifsc}`, b.upi && `UPI: ${b.upi}`]
    .filter(Boolean).map(esc).join("<br>") || "<i>Bank details not added yet</i>";
};

const band = (co, title, sub) => `
<div class="band">
  <div class="brand"><img src="/assets/logo.png" alt="${esc(co.name)}"></div>
  <div class="doc"><h1>${title}</h1><div>${sub}</div></div>
</div>`;

const footer = (co) => `<div class="foot"><b>${esc(co.website || "")}</b>${co.website && co.email ? " &nbsp;|&nbsp; " : ""}${esc(co.email || "")}</div>`;

const shell = (title, bar, content) => `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(title)}</title><style>${CSS}</style></head>
<body><div class="bar">${bar}</div><div class="page">${content}</div></body></html>`;

function renderDocument({ co, deal, doc }) {
  const isInvoice = doc.type === "invoice";
  const { total, lines } = taxBreakdown(doc.amount, Number(co.gstRate) || 0, co.gstin || "", deal.gstin || "");
  const taxRows = lines.map(([l, v]) => `<tr><td>${esc(l)}</td><td class="num">${inr(v)}</td></tr>`).join("");
  const terms = esc(co.terms || "") + (isInvoice ? "" : "<br><br>This is a proforma invoice for payment processing. It is not a tax invoice and cannot be used to claim input tax credit.");
  const content = `${band(co, isInvoice ? "TAX INVOICE" : "PROFORMA INVOICE", `${esc(doc.number)} &nbsp;|&nbsp; ${fd(doc.date)}`)}
<div class="body">
 <div class="cols"><div><h3>FROM</h3><br>${companyBlock(co)}</div><div><h3>BILL TO</h3><br>${clientBlock(deal)}</div></div>
 <div class="strip"><div><small>Payment mode</small>${esc(doc.payMode)}</div><div><small>Payment status</small>${esc(deal.paymentStatus)}</div><div><small>Product status</small>${esc(deal.productStatus)}</div></div>
 <div class="wrap"><table><tr><th style="width:44px">#</th><th>Description</th><th class="num" style="width:150px">Amount</th></tr>
  <tr><td>1</td><td>${esc(doc.description)}</td><td class="num">${inr(doc.amount)}</td></tr></table></div>
 <table class="totals"><tr><td>Taxable value</td><td class="num">${inr(doc.amount)}</td></tr>${taxRows}
  <tr class="grand"><td>Total</td><td class="num">${inr(total)}</td></tr></table>
 <p class="words"><b>Amount in words:</b> ${amountInWords(total)}</p>
 <div class="cols"><div><h3>BANK DETAILS</h3><br>${bankBlock(co)}</div><div><h3>TERMS</h3><br><span class="small">${terms}</span></div></div>
 <div class="sign">For <b>${esc(co.name)}</b>${co.showSeal !== false ? `<img class="seal" src="/assets/seal.png" alt="Company seal and signature">` : "<br><br><br>"}Authorised signatory</div>
</div>${footer(co)}`;
  return shell(doc.number,
    `<a href="/document/${esc(deal.id)}/${esc(doc.number)}/pdf"><button>Download PDF</button></a><button onclick="window.print()">Print</button>`, content);
}

function renderStatement({ co, deal }) {
  const rate = Number(co.gstRate) || 0;
  const rows = [];
  deal.documents.filter((x) => x.type === "invoice").forEach((x) =>
    rows.push({ date: new Date(x.date), ref: x.number, desc: `${x.description} (incl. GST @ ${rate}%)`, debit: x.amount + Math.round(x.amount * rate) / 100, credit: 0 }));
  deal.payments.forEach((x) =>
    rows.push({ date: new Date(x.date), ref: x.reference || "-", desc: `Payment received${x.type ? " - " + x.type : ""} - ${x.mode}`, debit: 0, credit: x.amount }));
  const earlier = deal.amountPaid - deal.payments.reduce((a, x) => a + x.amount, 0);
  if (earlier > 0.005) rows.push({ date: new Date(deal.createdAt), ref: "-", desc: "Payments recorded earlier", debit: 0, credit: earlier });
  rows.sort((a, b) => a.date - b.date);

  let bal = 0, totalDr = 0, totalCr = 0;
  const showBal = (n) => (n >= 0 ? inr(n) + " Dr" : inr(-n) + " Cr");
  const body = rows.map((r) => {
    bal += r.debit - r.credit; totalDr += r.debit; totalCr += r.credit;
    return `<tr><td>${fd(r.date)}</td><td>${esc(r.ref)}</td><td>${esc(r.desc)}</td><td class="num">${r.debit ? inr(r.debit) : ""}</td><td class="num">${r.credit ? inr(r.credit) : ""}</td><td class="num">${showBal(bal)}</td></tr>`;
  }).join("") || `<tr><td colspan="6" style="text-align:center">No invoices or payments yet</td></tr>`;

  const content = `${band(co, "STATEMENT OF ACCOUNT", `As on ${fd(new Date())}`)}
<div class="body">
 <div class="cols"><div><h3>CLIENT</h3><br>${clientBlock(deal)}</div>
  <div><h3>SUMMARY</h3><br>Product: ${esc(deal.product)}<br>Product value: ${inr(deal.value)}<br>Product status: ${esc(deal.productStatus)}<br>Payment status: ${esc(deal.paymentStatus)}</div></div>
 <div class="wrap"><table><thead><tr><th>Date</th><th>Reference</th><th>Description</th><th class="num">Invoiced</th><th class="num">Received</th><th class="num">Balance</th></tr></thead>
  <tbody>${body}</tbody>
  <tfoot><tr><td colspan="3">Total</td><td class="num">${inr(totalDr)}</td><td class="num">${inr(totalCr)}</td><td class="num">${showBal(bal)}</td></tr></tfoot></table></div>
 <p class="small">Dr = amount due from client. Cr = advance paid by client. Only tax invoices are counted; proforma invoices are not.</p>
 <div class="cols"><div><h3>PAY TO</h3><br>${bankBlock(co)}</div>
  <div><h3>NOTE</h3><br><span class="small">Please contact ${esc(co.email || "us")} for any mismatch.</span></div></div>
</div>${footer(co)}`;
  return shell(`Statement - ${deal.company}`, `<button onclick="window.print()">Print / Save as PDF</button>`, content);
}

module.exports = { renderDocument, renderStatement };

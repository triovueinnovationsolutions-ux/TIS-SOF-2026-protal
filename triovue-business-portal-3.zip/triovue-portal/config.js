// Where data files live. Set DATA_DIR on a hosting platform to point at a persistent disk.
const fs = require("fs");
const path = require("path");

const DEFAULT_DIR = path.join(__dirname, "data");
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : DEFAULT_DIR;
fs.mkdirSync(DATA_DIR, { recursive: true });

// First start with a custom DATA_DIR: copy the starter files in
if (DATA_DIR !== DEFAULT_DIR) {
  for (const f of ["deals.json", "company.json"]) {
    const target = path.join(DATA_DIR, f), source = path.join(DEFAULT_DIR, f);
    if (!fs.existsSync(target) && fs.existsSync(source)) fs.copyFileSync(source, target);
  }
}

module.exports = { DATA_DIR, file: (name) => path.join(DATA_DIR, name) };

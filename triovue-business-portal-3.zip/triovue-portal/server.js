const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
app.set("trust proxy", 1); // correct client IP and HTTPS detection behind Render/Railway/nginx
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "same-origin");
  next();
});
const PORT = process.env.PORT || 3000;
const cfg = require("./config");
const DB = cfg.file("deals.json");

const STAGES = ["Lead generated", "Discovery", "NDA", "MSA", "Proposal", "Payment phases", "Delivery"];
const PRODUCT_STATUSES = ["Not started", "In development", "40% delivered", "80% delivered", "POC delivered", "Completed"];
const PAYMENT_STATUSES = ["Pending", "Phase 1 paid", "Phase 2 paid", "Phase 3 paid", "Fully paid"];
const PAY_MODES = ["Bank transfer (NEFT/RTGS)", "UPI", "Cheque", "Cash", "Card"];
const COMPANY_FILE = cfg.file("company.json");
const LEAD_SOURCES = ["LinkedIn", "Website", "Referral", "Direct enquiry", "Other"];
const CONVERSION_STATUSES = ["New", "Contacted", "Qualified", "Proposal sent", "Negotiation", "Won", "Lost"];
const PAYMENT_TYPES = ["Advance", "Milestone", "Partial", "Final"];
const SCHEDULE_KINDS = ["Advance", "Milestone", "Final"];
const ACTIVITY_TYPES = ["Meeting", "Email", "Call", "Note"];
const str = (v, max = 300) => String(v ?? "").trim().slice(0, max);
const dateOnly = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v || "")) ? String(v) : "");
const todayStr = () => new Date().toLocaleDateString("en-CA"); // YYYY-MM-DD in local time
const newId = () => Date.now().toString(36) + require("crypto").randomBytes(2).toString("hex");

// small JSON log files (audit log, login history)
const readJson = (f, def) => { try { return JSON.parse(fs.readFileSync(cfg.file(f), "utf8")); } catch { return def; } };
const pushLog = (f, entry, cap) => { const a = readJson(f, []); a.push(entry); fs.writeFileSync(cfg.file(f), JSON.stringify(a.slice(-cap))); };
const company = () => JSON.parse(fs.readFileSync(COMPANY_FILE, "utf8"));

// Fill in defaults so older records without the new fields still work
const normalize = (d) => ({
  ...d,
  value: Number(d.value) || 0,
  amountPaid: Number(d.amountPaid) || 0,
  productStatus: PRODUCT_STATUSES.includes(d.productStatus) ? d.productStatus : PRODUCT_STATUSES[0],
  paymentStatus: PAYMENT_STATUSES.includes(d.paymentStatus) ? d.paymentStatus : PAYMENT_STATUSES[0],
  payMode: PAY_MODES.includes(d.payMode) ? d.payMode : PAY_MODES[0],
  active: d.active !== false,
  leadSource: LEAD_SOURCES.includes(d.leadSource) ? d.leadSource : "Direct enquiry",
  designation: str(d.designation, 100),
  enquiryDate: dateOnly(d.enquiryDate),
  nextFollowUp: dateOnly(d.nextFollowUp),
  nextAction: str(d.nextAction),
  leadOwner: str(d.leadOwner, 40),
  conversionStatus: CONVERSION_STATUSES.includes(d.conversionStatus) ? d.conversionStatus : "New",
  pendingResponse: str(d.pendingResponse),
  pendingSince: dateOnly(d.pendingSince),
  schedule: Array.isArray(d.schedule) ? d.schedule : [],
  activities: Array.isArray(d.activities) ? d.activities : [],
  billingAddress: d.billingAddress || "",
  gstin: (d.gstin || "").toUpperCase(),
  email: d.email || "",
  phone: d.phone || "",
  payments: Array.isArray(d.payments) ? d.payments : [],
  documents: Array.isArray(d.documents) ? d.documents : [],
});

const load = () => (fs.existsSync(DB) ? JSON.parse(fs.readFileSync(DB, "utf8")).map(normalize) : []);
const save = (deals) => fs.writeFileSync(DB, JSON.stringify(deals, null, 2));

// Payment schedule: money received is applied to milestones in due-date order, so partial payments
// and overdue amounts are worked out automatically.
function scheduleView(deal, today) {
  const items = [...deal.schedule].sort((a, b) => (a.dueDate || "9999").localeCompare(b.dueDate || "9999"));
  let left = deal.amountPaid;
  return items.map((it) => {
    const paid = Math.min(Math.max(left, 0), it.amount);
    left -= paid;
    const settled = paid >= it.amount - 0.005;
    const overdue = !settled && !!it.dueDate && it.dueDate < today;
    const daysOverdue = overdue ? Math.round((new Date(today) - new Date(it.dueDate)) / 86400000) : 0;
    return { ...it, paid, balance: it.amount - paid, overdue, daysOverdue, status: settled ? "Paid" : overdue ? "Overdue" : paid > 0 ? "Partly paid" : "Pending" };
  });
}
function withComputed(d, co) {
  const sv = scheduleView(d, todayStr());
  const rate = Number(co.gstRate) || 0;
  const g = taxBreakdown(d.value, rate, co.gstin || "", d.gstin || "");
  return { ...d, scheduleView: sv, overdueAmount: sv.filter((x) => x.overdue).reduce((a, x) => a + x.balance, 0), gst: { rate, tax: g.tax, total: g.total, lines: g.lines } };
}

// ---------- Users, login and roles ----------
const crypto = require("crypto");
const USERS_FILE = cfg.file("users.json");
const VIEW = (f) => path.join(__dirname, "views", f);
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString("hex");
const setPassword = (u, pw) => { u.salt = crypto.randomBytes(16).toString("hex"); u.hash = hashPw(pw, u.salt); delete u.isDefault; delete u.mustChange; return u; };
const makeUser = (username, password, role, isDefault) => { const u = setPassword({ username, role }, password); if (isDefault) u.isDefault = true; return u; };
const loadUsers = () => JSON.parse(fs.readFileSync(USERS_FILE, "utf8"));
const saveUsers = (u) => fs.writeFileSync(USERS_FILE, JSON.stringify(u, null, 2));
const checkPw = (u, pw) => {
  const a = Buffer.from(hashPw(pw, u.salt), "hex"), b = Buffer.from(u.hash, "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};

if (!fs.existsSync(USERS_FILE)) {
  saveUsers([makeUser("admin", "admin123", "admin", true), makeUser("employee", "employee123", "employee", true)]);
  console.log("Created default logins -> admin / admin123  and  employee / employee123  (change these after first login)");
}

const sessions = new Map();
const SESSION_MS = 8 * 60 * 60 * 1000;
const cookies = (req) =>
  Object.fromEntries((req.headers.cookie || "").split(";").map((c) => c.trim().split("=")).filter((p) => p[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join("="))]));
const sessionToken = (req) => {
  const t = cookies(req).sid, s = t && sessions.get(t);
  if (!s) return null;
  if (s.expires < Date.now()) { sessions.delete(t); return null; }
  return t;
};

const attempts = new Map();
app.use("/assets", express.static(path.join(__dirname, "assets"), { maxAge: "7d" })); // logo and seal (needed on the login page)
app.get("/healthz", (req, res) => res.type("text").send("ok"));
app.get("/login", (req, res) => (sessionToken(req) ? res.redirect("/") : res.sendFile(VIEW("login.html"))));

app.post("/api/login", express.json({ limit: "20kb" }), (req, res) => {
  const a = attempts.get(req.ip) || { n: 0, until: 0 };
  if (a.until > Date.now()) return res.status(429).json({ error: "Too many attempts. Try again in a few minutes." });
  const name = String(req.body.username || "").trim().toLowerCase();
  const u = loadUsers().find((x) => x.username === name);
  const logLogin = (success) => pushLog("logins.json", { time: new Date().toISOString(), username: name.slice(0, 50), success, ip: req.ip, agent: String(req.headers["user-agent"] || "").slice(0, 90) }, 1000);
  if (!u || !checkPw(u, String(req.body.password || ""))) {
    logLogin(false);
    a.n++;
    if (a.n >= 10) { a.until = Date.now() + 15 * 60 * 1000; a.n = 0; }
    attempts.set(req.ip, a);
    return res.status(401).json({ error: "Wrong username or password" });
  }
  logLogin(true);
  attempts.delete(req.ip);
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, { username: u.username, expires: Date.now() + SESSION_MS });
  res.setHeader("Set-Cookie", `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_MS / 1000}${req.secure ? "; Secure" : ""}`);
  res.json({ role: u.role });
});

// Everything below this line needs a valid login
app.use((req, res, next) => {
  const t = sessionToken(req);
  const u = t && loadUsers().find((x) => x.username === sessions.get(t).username);
  if (!u) {
    if (t) sessions.delete(t);
    return req.originalUrl.startsWith("/api") ? res.status(401).json({ error: "Please log in" }) : res.redirect("/login");
  }
  req.user = { username: u.username, role: u.role, isDefault: !!u.isDefault || !!u.mustChange };
  req.token = t;
  next();
});

app.use(express.json({ limit: "10mb" }));

// Employees can only read. Any API call that changes data needs the admin role.
const SELF_SERVICE = ["/logout", "/change-password"];
app.use("/api", (req, res, next) => {
  if (req.method !== "GET" && req.user.role !== "admin" && !SELF_SERVICE.includes(req.path))
    return res.status(403).json({ error: "View only: your account cannot make changes" });
  next();
});
const adminOnly = (req, res, next) => (req.user.role === "admin" ? next() : res.status(403).json({ error: "Admin access required" }));

// ---------- Audit log: who changed what (passwords are never recorded) ----------
const SENSITIVE = /pass|secret|token|hash|salt|current/i;
const brief = (b) => Object.entries(b || {}).filter(([k, v]) => !SENSITIVE.test(k) && v !== undefined && typeof v !== "object").map(([k, v]) => `${k}: ${String(v).slice(0, 60)}`).join(", ").slice(0, 220);
function describe(req, dealName) {
  const s = req.originalUrl.split("?")[0].replace(/^\/api\//, "").split("/").map(decodeURIComponent), b = req.body || {}, m = req.method;
  const on = dealName ? ` for "${dealName}"` : "";
  if (s[0] === "deals") {
    if (s.length === 1) return ["Create", `Created deal "${b.company || ""}"`];
    if (s.length === 2) return m === "DELETE" ? ["Delete", `Deleted deal "${dealName}"`] : ["Update", `Edited deal "${dealName}" (${brief(b)})`];
    if (s[2] === "documents") return ["Create", `Created ${b.type} of ₹${b.amount}${on}`];
    if (s[2] === "payments") return m === "POST" ? ["Create", `Recorded ${b.type || "payment"} of ₹${b.amount}${on}`] : ["Delete", `Removed a payment${on}`];
    if (s[2] === "schedule") return m === "POST" ? ["Create", `Added milestone "${b.name}" ₹${b.amount} due ${b.dueDate}${on}`] : ["Delete", `Removed a payment milestone${on}`];
    if (s[2] === "activities") return m === "POST" ? ["Create", `Logged ${b.type} "${b.subject || ""}"${on}`] : ["Delete", `Removed a communication entry${on}`];
  }
  if (s[0] === "users") return m === "POST" ? ["Security", `Added user ${b.username} (${b.role})`] : m === "PUT" ? ["Security", `Reset password for ${s[1]}`] : ["Security", `Deleted user ${s[1]}`];
  if (s[0] === "company") return ["Update", "Updated company settings"];
  if (s[0] === "change-password") return ["Security", "Changed own password"];
  if (s[0] === "logout") return null;
  if (s[0] === "backups" || s[0] === "restore") return ["Backup", s[0] === "restore" ? "Restored data from a backup" : "Created a backup"];
  return [m, `${m} /api/${s.join("/")}`];
}
app.use("/api", (req, res, next) => {
  if (req.method === "GET" || req.method === "HEAD") return next();
  const m = req.originalUrl.match(/^\/api\/deals\/([^/?]+)/);
  const dealName = m ? (load().find((d) => d.id === m[1]) || {}).company || "" : "";
  res.on("finish", () => {
    if (res.statusCode >= 400) return;
    const d = describe(req, dealName);
    if (d) pushLog("audit.json", { time: new Date().toISOString(), user: req.user.username, action: d[0], summary: d[1] }, 3000);
  });
  next();
});

app.get("/", (req, res) => res.redirect(req.user.role === "admin" ? "/admin" : "/employee"));
app.get("/admin", (req, res) => (req.user.role === "admin" ? res.sendFile(VIEW("app.html")) : res.redirect("/employee")));
app.get("/employee", (req, res) => (req.user.role === "employee" ? res.sendFile(VIEW("app.html")) : res.redirect("/admin")));

app.get("/api/me", (req, res) => {
  const co = company();
  const setupNeeded = req.user.role === "admin" && (!co.gstin || !co.address || !(co.bank && co.bank.accountNumber));
  res.json({ username: req.user.username, role: req.user.role, usingDefaultPassword: req.user.isDefault, setupNeeded, companyName: co.name });
});

// Company settings (admin only): these appear on every invoice, proforma and statement
const GSTIN_RE = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;
app.get("/api/company", adminOnly, (req, res) => res.json(company()));
app.put("/api/company", adminOnly, (req, res) => {
  const b = req.body || {}, cur = company();
  const str = (v, max = 300) => String(v ?? "").trim().slice(0, max);
  const gstin = str(b.gstin, 15).toUpperCase();
  if (!str(b.name)) return res.status(400).json({ error: "Company name is required" });
  if (gstin && !GSTIN_RE.test(gstin)) return res.status(400).json({ error: "GST number must be 15 characters, like 33ABCDE1234F1Z5" });
  const rate = Number(b.gstRate);
  if (!(rate >= 0 && rate <= 100)) return res.status(400).json({ error: "GST rate must be between 0 and 100" });
  const bk = b.bank || {};
  const next = {
    ...cur,
    name: str(b.name), address: str(b.address, 500), gstin, email: str(b.email), phone: str(b.phone, 40), website: str(b.website), gstRate: rate,
    bank: { accountName: str(bk.accountName), bankName: str(bk.bankName), accountNumber: str(bk.accountNumber, 40), ifsc: str(bk.ifsc, 20).toUpperCase(), upi: str(bk.upi, 80) },
    terms: str(b.terms, 600),
    showSeal: b.showSeal !== false,
  };
  fs.writeFileSync(COMPANY_FILE, JSON.stringify(next, null, 2));
  res.json(next);
});
app.post("/api/logout", (req, res) => {
  sessions.delete(req.token);
  res.setHeader("Set-Cookie", `sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${req.secure ? "; Secure" : ""}`);
  res.json({ ok: true });
});

const validPassword = (p) => typeof p === "string" && p.length >= 8;
app.post("/api/change-password", (req, res) => {
  const users = loadUsers();
  const u = users.find((x) => x.username === req.user.username);
  if (!checkPw(u, String(req.body.current || ""))) return res.status(400).json({ error: "Current password is wrong" });
  if (!validPassword(req.body.password)) return res.status(400).json({ error: "New password must be at least 8 characters" });
  setPassword(u, req.body.password);
  saveUsers(users);
  res.json({ ok: true });
});

// User management (admin only)
app.get("/api/users", adminOnly, (req, res) => {
  const logs = readJson("logins.json", []);
  res.json(loadUsers().map((u) => {
    const ok = logs.filter((l) => l.success && l.username === u.username);
    return { username: u.username, role: u.role, isDefault: !!u.isDefault || !!u.mustChange, lastLogin: ok.length ? ok[ok.length - 1].time : "", loginCount: ok.length };
  }));
});

app.post("/api/users", adminOnly, (req, res) => {
  const username = String(req.body.username || "").trim().toLowerCase();
  const role = req.body.role;
  if (!/^[a-z0-9._-]{3,30}$/.test(username)) return res.status(400).json({ error: "Username: 3-30 letters, numbers, . _ -" });
  if (!["admin", "employee"].includes(role)) return res.status(400).json({ error: "Role must be admin or employee" });
  if (!validPassword(req.body.password)) return res.status(400).json({ error: "Password must be at least 8 characters" });
  const users = loadUsers();
  if (users.some((u) => u.username === username)) return res.status(400).json({ error: "Username already exists" });
  users.push(makeUser(username, req.body.password, role, false));
  saveUsers(users);
  res.status(201).json({ username, role });
});

app.put("/api/users/:username", adminOnly, (req, res) => {
  const users = loadUsers();
  const u = users.find((x) => x.username === req.params.username);
  if (!u) return res.status(404).json({ error: "User not found" });
  if (!validPassword(req.body.password)) return res.status(400).json({ error: "Password must be at least 8 characters" });
  setPassword(u, req.body.password);
  u.mustChange = true; // the person must choose their own password at next login
  saveUsers(users);
  res.json({ ok: true });
});

app.delete("/api/users/:username", adminOnly, (req, res) => {
  const users = loadUsers();
  const u = users.find((x) => x.username === req.params.username);
  if (!u) return res.status(404).json({ error: "User not found" });
  if (u.username === req.user.username) return res.status(400).json({ error: "You cannot delete your own account" });
  if (u.role === "admin" && users.filter((x) => x.role === "admin").length === 1) return res.status(400).json({ error: "Cannot delete the last admin" });
  saveUsers(users.filter((x) => x.username !== u.username));
  res.json({ ok: true });
});

app.get("/api/options", (req, res) =>
  res.json({ stages: STAGES, productStatuses: PRODUCT_STATUSES, paymentStatuses: PAYMENT_STATUSES, payModes: PAY_MODES, leadSources: LEAD_SOURCES, conversionStatuses: CONVERSION_STATUSES, paymentTypes: PAYMENT_TYPES, scheduleKinds: SCHEDULE_KINDS, activityTypes: ACTIVITY_TYPES })
);
app.get("/api/deals", (req, res) => { const co = company(); res.json(load().map((d) => withComputed(d, co))); });

app.get("/api/stats", (req, res) => {
  const deals = load();
  const byStage = Object.fromEntries(STAGES.map((s) => [s, { count: 0, value: 0 }]));
  deals.forEach((d) => {
    if (byStage[d.stage]) {
      byStage[d.stage].count++;
      byStage[d.stage].value += d.value;
    }
  });
  const totalValue = deals.reduce((a, d) => a + d.value, 0);
  const received = deals.reduce((a, d) => a + d.amountPaid, 0);
  const activeDeals = deals.filter((d) => d.active).length;
  res.json({ totalDeals: deals.length, activeDeals, inactiveDeals: deals.length - activeDeals, totalValue, received, outstanding: totalValue - received, byStage });
});

app.post("/api/deals", (req, res) => {
  const b = req.body;
  if (!b.company || !b.company.trim()) return res.status(400).json({ error: "company is required" });
  const deals = load();
  const deal = normalize({
    id: Date.now().toString(36),
    company: b.company.trim(),
    contact: b.contact || "",
    product: b.product || "Other",
    value: b.value,
    amountPaid: b.amountPaid,
    stage: STAGES.includes(b.stage) ? b.stage : STAGES[0],
    productStatus: b.productStatus,
    paymentStatus: b.paymentStatus,
    payMode: b.payMode,
    billingAddress: b.billingAddress,
    gstin: b.gstin,
    email: b.email,
    phone: b.phone,
    notes: b.notes || "",
    leadSource: b.leadSource, designation: b.designation, enquiryDate: b.enquiryDate || todayStr(), nextFollowUp: b.nextFollowUp,
    nextAction: b.nextAction, leadOwner: b.leadOwner, conversionStatus: b.conversionStatus,
    pendingResponse: b.pendingResponse, pendingSince: b.pendingResponse ? todayStr() : "",
    createdAt: new Date().toISOString(),
  });
  deals.push(deal);
  save(deals);
  res.status(201).json(deal);
});

app.put("/api/deals/:id", (req, res) => {
  const deals = load();
  const i = deals.findIndex((d) => d.id === req.params.id);
  if (i === -1) return res.status(404).json({ error: "not found" });
  const allowed = ["company", "contact", "product", "value", "amountPaid", "stage", "productStatus", "paymentStatus", "payMode", "active", "billingAddress", "gstin", "email", "phone", "notes", "leadSource", "designation", "enquiryDate", "nextFollowUp", "nextAction", "leadOwner", "conversionStatus", "pendingResponse"];
  const prevPending = deals[i].pendingResponse;
  allowed.forEach((k) => {
    if (req.body[k] !== undefined) deals[i][k] = req.body[k];
  });
  if (req.body.pendingResponse !== undefined) {
    if (!str(req.body.pendingResponse)) deals[i].pendingSince = "";
    else if (!prevPending) deals[i].pendingSince = todayStr();
  }
  deals[i] = normalize(deals[i]);
  save(deals);
  res.json(deals[i]);
});

app.delete("/api/deals/:id", (req, res) => {
  const deals = load();
  const next = deals.filter((d) => d.id !== req.params.id);
  if (next.length === deals.length) return res.status(404).json({ error: "not found" });
  save(next);
  res.json({ ok: true });
});

// ---------- Invoice / Proforma ----------
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const { inr, amountInWords, taxBreakdown } = require("./billing");
const { buildPdf } = require("./pdf");
const { renderDocument, renderStatement } = require("./templates");

function financialYear(date) {
  const y = date.getFullYear(), m = date.getMonth();
  const start = m >= 3 ? y : y - 1;
  return `${start}-${String(start + 1).slice(2)}`;
}

function nextNumber(deals, type, date) {
  const prefix = type === "invoice" ? "INV" : "PF";
  const fy = financialYear(date);
  const used = deals.flatMap((d) => d.documents).filter((x) => x.type === type && x.number.startsWith(`${prefix}-${fy}-`)).length;
  return `${prefix}-${fy}-${String(used + 1).padStart(4, "0")}`;
}

app.post("/api/deals/:id/documents", (req, res) => {
  const deals = load();
  const deal = deals.find((d) => d.id === req.params.id);
  if (!deal) return res.status(404).json({ error: "deal not found" });
  const { type, description } = req.body;
  const amount = Number(req.body.amount);
  if (!["invoice", "proforma"].includes(type)) return res.status(400).json({ error: "type must be invoice or proforma" });
  if (!(amount > 0)) return res.status(400).json({ error: "amount must be greater than 0" });
  const now = new Date();
  const doc = {
    number: nextNumber(deals, type, now),
    type,
    date: now.toISOString(),
    amount,
    description: description || `${deal.product} - ${deal.stage}`,
    payMode: deal.payMode,
  };
  deal.documents.push(doc);
  save(deals);
  res.status(201).json({ ...doc, url: `/document/${deal.id}/${doc.number}` });
});

app.get("/document/:dealId/:number/pdf", (req, res) => {
  const deal = load().find((d) => d.id === req.params.dealId);
  const doc = deal && deal.documents.find((x) => x.number === req.params.number);
  if (!doc) return res.status(404).send("Document not found");
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `inline; filename="${doc.number}.pdf"`);
  const pdf = buildPdf({ company: company(), deal, doc });
  pdf.pipe(res);
  pdf.end();
});

app.get("/document/:dealId/:number", (req, res) => {
  const deal = load().find((d) => d.id === req.params.dealId);
  const doc = deal && deal.documents.find((x) => x.number === req.params.number);
  if (!doc) return res.status(404).send("Document not found");
  res.send(renderDocument({ co: company(), deal, doc }));
});

// ---------- Payments ledger & statement of account ----------
app.post("/api/deals/:id/payments", (req, res) => {
  const deals = load();
  const deal = deals.find((d) => d.id === req.params.id);
  if (!deal) return res.status(404).json({ error: "deal not found" });
  const amount = Number(req.body.amount);
  if (!(amount > 0)) return res.status(400).json({ error: "amount must be greater than 0" });
  const p = {
    id: Date.now().toString(36),
    date: dateOnly(req.body.date) || todayStr(),
    amount,
    type: PAYMENT_TYPES.includes(req.body.type) ? req.body.type : "Partial",
    mode: PAY_MODES.includes(req.body.mode) ? req.body.mode : deal.payMode,
    reference: req.body.reference || "",
  };
  deal.payments.push(p);
  deal.amountPaid += amount;
  save(deals);
  res.status(201).json(p);
});

app.delete("/api/deals/:id/payments/:pid", (req, res) => {
  const deals = load();
  const deal = deals.find((d) => d.id === req.params.id);
  const p = deal && deal.payments.find((x) => x.id === req.params.pid);
  if (!p) return res.status(404).json({ error: "payment not found" });
  deal.payments = deal.payments.filter((x) => x.id !== p.id);
  deal.amountPaid = Math.max(0, deal.amountPaid - p.amount);
  save(deals);
  res.json({ ok: true });
});


// ---------- Payment schedule (milestones, advance, due dates) ----------
app.post("/api/deals/:id/schedule", (req, res) => {
  const deals = load();
  const deal = deals.find((d) => d.id === req.params.id);
  if (!deal) return res.status(404).json({ error: "deal not found" });
  const amount = Number(req.body.amount), dueDate = dateOnly(req.body.dueDate), name = str(req.body.name, 80);
  if (!name) return res.status(400).json({ error: "Milestone name is required" });
  if (!(amount > 0)) return res.status(400).json({ error: "amount must be greater than 0" });
  if (!dueDate) return res.status(400).json({ error: "Due date is required (YYYY-MM-DD)" });
  const item = { id: newId(), name, kind: SCHEDULE_KINDS.includes(req.body.kind) ? req.body.kind : "Milestone", amount, dueDate };
  deal.schedule.push(item);
  save(deals);
  res.status(201).json(item);
});
app.delete("/api/deals/:id/schedule/:sid", (req, res) => {
  const deals = load();
  const deal = deals.find((d) => d.id === req.params.id);
  if (!deal || !deal.schedule.some((x) => x.id === req.params.sid)) return res.status(404).json({ error: "milestone not found" });
  deal.schedule = deal.schedule.filter((x) => x.id !== req.params.sid);
  save(deals);
  res.json({ ok: true });
});

// ---------- Communication log: meetings, emails, calls, discussion notes ----------
app.post("/api/deals/:id/activities", (req, res) => {
  const deals = load();
  const deal = deals.find((d) => d.id === req.params.id);
  if (!deal) return res.status(404).json({ error: "deal not found" });
  const type = req.body.type;
  if (!ACTIVITY_TYPES.includes(type)) return res.status(400).json({ error: "Choose Meeting, Email, Call or Note" });
  const subject = str(req.body.subject, 120), notes = str(req.body.notes, 2000);
  if (!subject && !notes) return res.status(400).json({ error: "Add a subject or some notes" });
  const entry = {
    id: newId(), type, date: dateOnly(req.body.date) || todayStr(), subject, notes,
    direction: type === "Email" && ["Sent", "Received"].includes(req.body.direction) ? req.body.direction : "",
    by: req.user.username, createdAt: new Date().toISOString(),
  };
  deal.activities.push(entry);
  save(deals);
  res.status(201).json(entry);
});
app.delete("/api/deals/:id/activities/:aid", (req, res) => {
  const deals = load();
  const deal = deals.find((d) => d.id === req.params.id);
  if (!deal || !deal.activities.some((x) => x.id === req.params.aid)) return res.status(404).json({ error: "entry not found" });
  deal.activities = deal.activities.filter((x) => x.id !== req.params.aid);
  save(deals);
  res.json({ ok: true });
});

// ---------- Admin: audit log and login history ----------
const newestFirst = (arr, user, q, limit) => arr.filter((e) => (!user || (e.user || e.username) === user) && (!q || JSON.stringify(e).toLowerCase().includes(q))).reverse().slice(0, limit);
app.get("/api/audit", adminOnly, (req, res) =>
  res.json(newestFirst(readJson("audit.json", []), str(req.query.user, 50), str(req.query.q, 80).toLowerCase(), Math.min(Number(req.query.limit) || 200, 1000))));
app.get("/api/logins", adminOnly, (req, res) =>
  res.json(newestFirst(readJson("logins.json", []), str(req.query.user, 50), "", Math.min(Number(req.query.limit) || 100, 1000))));

// ---------- Admin: data backup and recovery ----------
const BACKUP_DIR = path.join(cfg.DATA_DIR, "backups");
const BACKUP_RE = /^backup-[0-9TZ-]+(-[a-z]+)?\.json$/;
const rawDeals = () => (fs.existsSync(DB) ? JSON.parse(fs.readFileSync(DB, "utf8")) : []);
function backupNow(tag) {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const name = `backup-${new Date().toISOString().replace(/[:.]/g, "-")}${tag ? "-" + tag : ""}.json`;
  const snap = { app: "triovue-portal", version: 1, createdAt: new Date().toISOString(), deals: rawDeals(), company: company(), users: loadUsers(), audit: readJson("audit.json", []), logins: readJson("logins.json", []) };
  fs.writeFileSync(path.join(BACKUP_DIR, name), JSON.stringify(snap));
  const files = fs.readdirSync(BACKUP_DIR).filter((f) => BACKUP_RE.test(f)).sort();
  files.slice(0, Math.max(0, files.length - 30)).forEach((f) => fs.unlinkSync(path.join(BACKUP_DIR, f))); // keep the newest 30
  return name;
}
function backupProblem(b) {
  if (!b || typeof b !== "object") return "This is not a backup file";
  if (!Array.isArray(b.deals) || !b.deals.every((d) => d && typeof d.id === "string" && typeof d.company === "string")) return "The deals data in this backup is invalid";
  if (!b.company || typeof b.company.name !== "string") return "The company data in this backup is invalid";
  if (!Array.isArray(b.users) || !b.users.every((u) => u && typeof u.username === "string" && ["admin", "employee"].includes(u.role) && typeof u.hash === "string" && typeof u.salt === "string")) return "The users data in this backup is invalid";
  if (!b.users.some((u) => u.role === "admin")) return "This backup has no admin user, so you could not sign in afterwards";
  return null;
}
app.get("/api/backups", adminOnly, (req, res) => {
  if (!fs.existsSync(BACKUP_DIR)) return res.json([]);
  res.json(fs.readdirSync(BACKUP_DIR).filter((f) => BACKUP_RE.test(f)).sort().reverse()
    .map((name) => { const st = fs.statSync(path.join(BACKUP_DIR, name)); return { name, size: st.size, time: st.mtime.toISOString() }; }));
});
app.post("/api/backups", adminOnly, (req, res) => res.status(201).json({ name: backupNow("manual") }));
app.get("/api/backups/:name/download", adminOnly, (req, res) => {
  if (!BACKUP_RE.test(req.params.name) || !fs.existsSync(path.join(BACKUP_DIR, req.params.name))) return res.status(404).json({ error: "backup not found" });
  res.download(path.join(BACKUP_DIR, req.params.name));
});
app.post("/api/restore", adminOnly, (req, res) => {
  let b = req.body.backup;
  if (!b && req.body.name) {
    if (!BACKUP_RE.test(req.body.name) || !fs.existsSync(path.join(BACKUP_DIR, req.body.name))) return res.status(404).json({ error: "backup not found" });
    b = JSON.parse(fs.readFileSync(path.join(BACKUP_DIR, req.body.name), "utf8"));
  }
  const problem = backupProblem(b);
  if (problem) return res.status(400).json({ error: problem });
  const safetyCopy = backupNow("prerestore"); // so a restore can itself be undone
  fs.writeFileSync(DB, JSON.stringify(b.deals, null, 2));
  fs.writeFileSync(COMPANY_FILE, JSON.stringify(b.company, null, 2));
  saveUsers(b.users);
  res.json({ ok: true, deals: b.deals.length, users: b.users.length, safetyCopy });
});

app.get("/statement/:dealId", (req, res) => {
  const deal = load().find((d) => d.id === req.params.dealId);
  if (!deal) return res.status(404).send("Deal not found");
  res.send(renderStatement({ co: company(), deal }));
});

// Automatic backups: one at start-up (if none in the last 12 hours) and then every 24 hours
try {
  const recent = fs.existsSync(BACKUP_DIR) && fs.readdirSync(BACKUP_DIR).filter((f) => BACKUP_RE.test(f)).some((f) => Date.now() - fs.statSync(path.join(BACKUP_DIR, f)).mtimeMs < 12 * 3600 * 1000);
  if (!recent) backupNow("auto");
  setInterval(() => { try { backupNow("auto"); } catch (e) { console.error("Auto backup failed:", e.message); } }, 24 * 3600 * 1000).unref();
} catch (e) { console.error("Backup setup failed:", e.message); }

app.listen(PORT, () => console.log(`Triovue business tracker running at http://localhost:${PORT}  (data folder: ${cfg.DATA_DIR})`));
